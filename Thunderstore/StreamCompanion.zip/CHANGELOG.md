## 2.3.0

- Fixed issue preventing compatibility with Seekers of the Storm DLC

## 2.2.0

- Now works with skills

## 2.1.0

- Item updates are now sent in chunks instead of individually during the phase 4 Mithrix fight

## 2.0.0

- Changed networking to work with new backend

## 1.0.0

- First release