## 1.1.0

- Changed networking to work with new backend

## 1.0.0

- First release