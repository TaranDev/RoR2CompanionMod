# RoR2 Stream Companion

Mod component for the [RoR2 Stream Companion](https://dashboard.twitch.tv/extensions/pyjwzp6a2cbff88l10b8tpmhg668p9) Twitch extension. Uploads items, equipment, and skills to the backend database. 

Setup instructions can be found on the twitch extension config page.