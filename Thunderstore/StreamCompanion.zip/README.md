# RoR2 Stream Companion

Mod component for the RoR2 Stream Companion Twitch extension. Uploads items and equipment to the backend database.